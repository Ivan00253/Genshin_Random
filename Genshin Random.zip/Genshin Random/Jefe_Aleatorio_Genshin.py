import random,csv
from collections import namedtuple,defaultdict

version = 5.4
Jefe = namedtuple("Jefe",["nombre","debil"])
Personaje = namedtuple("Personaje","nombre,elemento,rol")

def leer_fichero_jefes(): # Esta función se encarga de pasar el archivo csv de los jefes a una lista
    with open("data/Jefes.csv",encoding="utf-8") as f:
        lector = csv.reader(f,delimiter=";")
        lista_jefes = [Jefe(nombre,debil) for nombre,debil in lector]
    return lista_jefes

def leer_fichero_personajes(): # Esta función se encarga de pasar el archivo csv de los personajes a una lista
    with open("data/Genshin_Impact_Personajes.csv",encoding="utf-8") as f:
        lector = csv.reader(f)
        next(lector)
        lista_personaje = [Personaje(nombre,elemento,rol) for nombre,elemento,rol in lector]
    return lista_personaje

def Elegir_jefe(): # Elige y muestra un jefe aleatorio de la lista anterior (La lista de jefes)
    opcion = random.choice(lista_jefes)
    print(f"El jefe es: {opcion.nombre} y es debil a los elementos: {opcion.debil}") 
    volver_a_elegir = input("¿Volver a elegir? (S/N)").upper()
    if volver_a_elegir == "S":
        Volver_a_elegir()
    else:
        Interfaz()

def Elegir_personaje(): # Elige y muestra un personaje aleatorio de la lista de personajes
    opcion = random.choice(lista_personaje)
    if opcion.nombre == "Aether (Viajero)":
        nombre = opcion.nombre + opcion.elemento
        opcion = Personaje(nombre=nombre,elemento=random.choices(opcion.elemento.split("/")))
    print(f"El personaje es: {opcion.nombre} y es del elemento: {opcion.elemento}") 
    volver_a_elegir = input("¿Volver a elegir? (S/N)").upper()
    if volver_a_elegir == "S":
        Volver_a_elegir_personaje()
    else:
        Interfaz()

def Elegir_equipo(): # Elige 4 personajes aleatorios de la lista de personajes y los muestra por pantalla
    equipo = []
    cons = defaultdict(int)
    equipo_elementos = []
    while len(equipo) != 4:
        personaje = random.choice(lista_personaje)
        if personaje not in equipo:
            if personaje.nombre == "Aether (Viajero)":
                elemento = random.choice(personaje.elemento.split("/"))
                nombre = f"{personaje.nombre} {elemento}"
                personaje = Personaje(nombre, elemento)
            equipo.append(personaje)
            cons[personaje.elemento] += 1

    for elemento in cons.items(): # Este fragmento de codigo se encarga de calcular la consonancia elemental del equipo
        if elemento[1] >= 2:
            equipo_elementos.append(elemento[0])
    if len(equipo_elementos) >= 2:
        consonancia = f"{equipo_elementos[0]} y {equipo_elementos[1]}"
    elif len(equipo_elementos) == 1:
        consonancia = f"{equipo_elementos[0]}"
    else:
        consonancia = "4 elementos"

    print(f"El equipo es: {equipo[0].nombre}, {equipo[1].nombre}, {equipo[2].nombre}, {equipo[3].nombre}. El equipo tiene una consonancia con: {consonancia}")
    volver_a_elegir = input("¿Volver a elegir? (S/N)").upper()
    if volver_a_elegir == "S":
        Volver_elegir_equipo()
    else:
        Interfaz()

def Elegir_equipo_pred(): # Elige 4 personajes aleatorios pero esta vez filtrados por el parametro rol y crea un equipo con un poco mas de sentido 
    equipo = []
    cons = defaultdict(int)
    equipo_elementos = []
    lista_rol = ["Dps","Subdps","Support","Healer"]
    i = 0
    while len(equipo) < 4:
        personaje = random.choice(lista_personaje)
        while personaje.rol != lista_rol[i]:
            if personaje not in equipo:
                if personaje.nombre == "Aether (Viajero)":
                    elemento = random.choice(personaje.elemento.split("/"))
                    nombre = f"{personaje.nombre} {elemento}"
                    personaje = Personaje(nombre, elemento, personaje.rol)
            personaje = random.choice(lista_personaje)
        equipo.append(personaje)
        i += 1

    for elemento in cons.items(): # Este es el mismo fragmento que el la funcion de Elegir_equipo
        if elemento[1] >= 2:
            equipo_elementos.append(elemento[0])
    if len(equipo_elementos) >= 2:
        consonancia = f"{equipo_elementos[0]} y {equipo_elementos[1]}"
    elif len(equipo_elementos) == 1:
        consonancia = f"{equipo_elementos[0]}"
    else:
        consonancia = "4 elementos"

    print(f"El equipo es: {equipo[0].nombre}, {equipo[1].nombre}, {equipo[2].nombre}, {equipo[3].nombre}. El equipo tiene una consonancia con: {consonancia}")
    volver_a_elegir = input("¿Volver a elegir? (S/N)").upper()
    if volver_a_elegir == "S":
        Volver_elegir_equipo_pred()
    else:
        Interfaz()

# Las funciones de volver a elegir se encargan de volver a llamar a la funcion que se quiera volver a ejecutar
def Volver_elegir_equipo():
    Elegir_equipo()

def Volver_elegir_equipo_pred():
    Elegir_equipo_pred()

def Volver_a_elegir():
    Elegir_jefe()

def Volver_a_elegir_personaje():
    Elegir_personaje()

def Interfaz(): # Esta funcion es la interfaz 
    print(f"Version del juego: {version}")
    print("Elige la opción que quiera: ")
    print("1. Jefe Aleatorio")
    print("2. Personaje Aleatorio")
    print("3. Equipo Aleatorio")
    print("4. Salir")
    opcion = int(input("Elige una opción: "))
    if opcion == 1:
        Elegir_jefe()
    elif opcion == 2:
        Elegir_personaje()
    elif opcion == 3:
        print("¿Quieres crear un equipo con roles o totalmente aleatorio?")
        print("1. Equipo con roles")
        print("2. Equipo aleatorio")
        print("3. Volver")
        opcion_pred = int(input("Elige una opción: "))
        if opcion_pred == 1:
            Elegir_equipo_pred()
        elif opcion_pred == 2:
            Elegir_equipo()
        else:
            Interfaz()
    else:
        print("¡¡Adios!!")
        input()

if __name__ == "__main__": # Este fragmento se encarga de inicializar todo el programa
    lista_jefes = leer_fichero_jefes()
    lista_personaje = leer_fichero_personajes()

    print("Bienvenido al selector de jefes y personajes aleatorio :D ...")
    Interfaz()